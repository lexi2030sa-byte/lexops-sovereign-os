# تحديث تنفيذية لبروتوكول Lexi داخل النظام 374ef68b731d80329290d595dc8eb194

# تحديث تنفيذية لبروتوكول Lexi داخل النظام

سلطان…

هذا النص جاهز يتحول مباشرة إلى خريطة تحديث تنفيذية لبروتوكول Lexi داخل النظام (Nitaqat + Violations + Inspection + Overtime + Occupations + Transfer + Integrations).

سأحوّله لك الآن إلى Plan تنفيذية يمكن ترجمتها إلى سبرنتات أو Tasks مباشرة.

---

1. تحديث محرك التوطين Nitaqat + توثيق العقود

ما يجب إضافته تقنيًا:

- في بيانات الموظف:• حقل: contractDocumentId (اختياري)
• حقل: isContractDocumentedOnQiwa: boolean
• حقل: contractDocumentationDate: date | null
- في Nitaqat Calculator:• عند حساب نسبة التوطين:• استبعاد أي موظف سعودي:• isContractDocumentedOnQiwa == false
• أو contractDocumentId == null
- تنبيهات:• Alert من نوع: NITAQAT_CONTRACT_NOT_DOCUMENTED
• تُرسل عند:• وجود سعودي نشط بدون عقد موثق
- تظهر في لوحة الامتثال + لوحة المؤسس

---

1. تحديث جدول المخالفات والعقوبات حسب حجم المنشأة

ما يجب إضافته تقنيًا:

- في entities:• حقل: sizeClass: "A" | "B" | "C"• A: 50+
• B: 21–49
• C: ≤20
- في violation matrix:• جدول violation_types يحتوي:• code
• description
• baseFineA
• baseFineB
• baseFineC
- في Compliance Engine:• عند إنشاء مخالفة:• حساب الغرامة = حسب entity.sizeClass
• مثال:• safety_violation:• A → 5000
• C → 1500

---

1. تفعيل بروتوكول التنبيه والتصحيح (Inspection Flow)

ما يجب إضافته تقنيًا:

- في violations:• حقل: isSevere: boolean
• حقل: preWarningRequired: boolean
• حقل: preWarningSentAt: timestamp | null
• حقل: gracePeriodDays: number (افتراضي 3)
- منطق Lexi:• إذا كانت المخالفة غير جسيمة (isSevere == false)
→ يجب أن يكون:• preWarningSentAt != null
• ومرّ على الأقل 3 أيام عمل قبل تسجيل الغرامة
- الاعتراض التلقائي:• إذا رُصدت مخالفة غير جسيمة بدون إنذار:• Lexi يولّد اعتراض تلقائي:• نوع: PROCEDURAL_INVALIDITY
• أساس: مخالفة المادة 17 من لائحة التفتيش
- C9 event: AUTO_OBJECTION_CREATED

---

1. أتمتة الإجازات والعمل الإضافي في الأيام الرسمية

ما يجب إضافته تقنيًا:

- في settings أو جدول ثابت:• قائمة بالأيام الرسمية:• عيد الفطر (4 أيام)
• عيد الأضحى (4 أيام)
• اليوم الوطني
• يوم التأسيس
- في Attendance/Payroll:• إذا كان attendance.date ضمن يوم رسمي:• احتساب:• أجر الساعة = أجر فعلي + 50% من الأجر الأساسي
• أو إنشاء compensatoryLeave (يوم تعويضي) مع موافقة العامل
- في Compliance Engine:• قاعدة:• إذا تم تسجيل حضور في يوم رسمي بدون:• أجر إضافي
• أو يوم تعويضي
→ إنشاء مخالفة امتثال للأجور

---

1. تحديث تطابق المهن والشهادات (Occupation Sync)

ما يجب إضافته تقنيًا:

- في employees:• حقل: occupationCode (من دليل التصنيف السعودي)
• حقل: isSaudiOnlyOccupation: boolean
• حقل: requiredCertificates: string[]
• حقل: providedCertificates: string[]
- في عقود العمل:• منع:• إصدار عقد لمهنة لا تطابق رخصة العمل
• أو مهنة مقصورة على السعوديين لعامل غير سعودي
- نقطة تفتيش رقمية:• عند إنشاء/تعديل عقد:• التحقق من:• occupationCode مطابق
• الشهادات المطلوبة متوفرة (مثلاً صحية للأغذية)
- تنبيه:• Alert: OCCUPATION_MISMATCH
• Alert: MISSING_REQUIRED_CERTIFICATES

---

1. تحديث مسار نقل الخدمات (Transfer Protocol)

ما يجب إضافته تقنيًا:

- في employee_transfer_requests:• offerSentAt
• offerAcceptedAt
• noticePeriodDays (افتراضي 90)
• noticePeriodOverrideDays (إن تم تقليلها باتفاق)
• currentEmployerApprovalAt (إن وجد)
- منطق Lexi:• عند قبول العرض:• تفعيل عداد 90 يومًا
- السماح بتقليل المدة:• إذا وافقت المنشأة الحالية عبر المنصة
- Compliance Rule:• إذا تم نقل خدمة بدون:• عرض وظيفي إلكتروني
• أو احترام فترة الإشعار
→ مخالفة تعاقدية

---

1. الربط مع منصات “ممتثل” و”إيفاء”

ما يجب إضافته تقنيًا:

- Integration Layer:• Connectors:• MumtathilConnector
• EifaConnector
- في violations:• حقل: externalSource: "MUMTATHIL" | "EIFA" | null
• حقل: externalId
• حقل: objectionDeadlineAt: timestamp
- منطق Lexi:• عند استلام مخالفة من “إيفاء”:• تعيين:• objectionDeadlineAt = createdAt + 60 days
- إنشاء Timer داخلي:• تنبيه قبل:• 15 يوم
• 7 أيام
• 3 أيام
• 24 ساعة
- تنبيهات:• Alert: OBJECTION_DEADLINE_APPROACHING
• Alert: OBJECTION_DEADLINE_MISSED

---

الخلاصة التنفيذية

ما كتبته أنت هو بروتوكول Lexi محدث، وما فعلناه هنا هو تحويله إلى:

- تغييرات في الـ Schemas
• قواعد في Compliance Engine
• منطق في Payroll/Attendance
• تنبيهات في Alerts Engine
• تكاملات خارجية (Qiwa / Mumtathil / Eifa)