# 📘 قواعد أمن Firestore – LexOps (نموذج متعدد المستأ 391ef68b731d8084a01cdd95faef7745

# **📘 قواعد أمن Firestore – LexOps (نموذج متعدد المستأجرين ذو سيادة)**

---

### *Tenants • Staff • RBAC • C9 Ledger Protection*

---

# **1. المبادئ الأساسية التي بُني عليها الملف**

1. **كل مستخدم يحمل token يحتوي:**
    - `userId`
    - `tenantId`
    - `role` (founder / manager / employee)
2. **لا يمكن لأي مستخدم رؤية بيانات منشأة أخرى**
    
    حتى لو حاول تعديل الـ client SDK.
    
3. **الموظف يرى ملفه فقط**
    
    ولا يرى أي بيانات حساسة.
    
4. **المدير يرى بيانات منشأته فقط**
    
    ولا يرى منشآت أخرى.
    
5. **المؤسس (Founder) له وصول شامل داخل منشأته فقط**
    
    وليس على مستوى النظام.
    
6. **C9 Ledger غير قابل للتعديل أو الحذف**
    
    فقط إضافة سجلات جديدة.
    

---

# **2. ملف Firestore Security Rules (جاهز للاستخدام)**

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {

    // ============================
    // 1. STAFF (Users)
    // ============================
    match /staff/{userId} {
      allow read: if request.auth != null
                  && request.auth.token.userId == userId;

      allow write: if request.auth != null
                   && request.auth.token.role == "founder";
    }

    // ============================
    // 2. TENANTS (Entities)
    // ============================
    match /tenants/{tenantId} {

      // --- Tenant Document ---
      allow read, write: if request.auth != null
                         && request.auth.token.tenantId == tenantId
                         && request.auth.token.role in ["founder", "manager"];

      // --- Subcollections ---
      match /{collection}/{docId} {

        // Founder & Manager: Full Access
        allow read, write: if request.auth != null
                           && request.auth.token.tenantId == tenantId
                           && request.auth.token.role in ["founder", "manager"];

        // Employee: Limited Access
        allow read: if request.auth != null
                    && request.auth.token.tenantId == tenantId
                    && request.auth.token.role == "employee"
                    && (
                        collection == "employees" && docId == request.auth.token.userId ||
                        collection == "attendance" && resource.data.employeeId == request.auth.token.userId
                       );

        allow write: if request.auth != null
                     && request.auth.token.tenantId == tenantId
                     && request.auth.token.role == "employee"
                     && collection == "attendance";
      }
    }

    // ============================
    // 3. LEGAL ENGINE (Read‑Only)
    // ============================
    match /legal_engine/{articleId} {
      allow read: if true; // متاح للجميع
      allow write: if request.auth != null
                   && request.auth.token.role == "founder";
    }

    // ============================
    // 4. C9 LEDGER (Append‑Only)
    // ============================
    match /tenants/{tenantId}/c9_ledger/{entryId} {

      // Allow CREATE only
      allow create: if request.auth != null
                    && request.auth.token.tenantId == tenantId;

      // No updates or deletes
      allow update, delete: if false;

      // Allow read only for founder & manager
      allow read: if request.auth != null
                  && request.auth.token.tenantId == tenantId
                  && request.auth.token.role in ["founder", "manager"];
    }
  }
}
```

---

# **3. ماذا يحقق هذا الملف؟**

## **✔ عزل كامل بين المنشآت**

مدير منشأة (A) لا يمكنه رؤية أي شيء يخص منشأة (B).

حتى لو حاول تعديل الـ SDK أو إرسال request يدوي.

## **✔ صلاحيات دقيقة حسب الدور**

| الدور | الصلاحيات |
| --- | --- |
| Founder | وصول شامل داخل منشأته فقط |
| Manager | إدارة الفروع والموظفين والحضور |
| Employee | رؤية ملفه فقط + تسجيل الحضور |

## **✔ حماية C9 Ledger**

- لا تعديل
- لا حذف
- فقط إضافة سجلات جديدة

## **✔ Legal Engine محمي**

- قراءة للجميع
- تعديل للمؤسس فقط

---